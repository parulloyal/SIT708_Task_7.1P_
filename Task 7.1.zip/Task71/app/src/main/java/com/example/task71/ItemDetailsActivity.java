package com.example.task71;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.task71.databinding.ActivityItemDetailsBinding;
import com.google.gson.Gson;
import java.util.List;

public class ItemDetailsActivity extends AppCompatActivity {
    private ActivityItemDetailsBinding binding;
    private List<LostFoundData> itemList;
    private static final int ITEM_DELETED_RESULT_CODE = 1001;
    private ItemListAdapter adapter;


    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityItemDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        itemList = (List<LostFoundData>) getIntent().getSerializableExtra("itemList");
        position = getIntent().getIntExtra("position", -1);

        if (itemList != null && position != -1 && position < itemList.size()) {
            LostFoundData clickedItem = itemList.get(position);
            binding.tvName.setText("-- Name: "+clickedItem.getName());
            binding.tvPhone.setText("-- Phone: "+clickedItem.getPhone());
            binding.tvDescription.setText("-- Description: "+clickedItem.getDescription());
            binding.tvDate.setText("-- Date: "+clickedItem.getDate());
            binding.tvLocation.setText("-- Location: "+clickedItem.getLocation());
            binding.tvRemove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDeleteButtonClick();
                }
            });
        } else {
            Toast.makeText(this, "Error: Unable to retrieve item details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void onDeleteButtonClick() {
        if (position != -1 && position < itemList.size()) {
            itemList.remove(position);
            updateSharedPreferences();
            setResult(ITEM_DELETED_RESULT_CODE); // Set result indicating item deletion
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void updateSharedPreferences() {
        Gson gson = new Gson();
        String json = gson.toJson(itemList);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("itemList", json);
        editor.apply();
    }
}
