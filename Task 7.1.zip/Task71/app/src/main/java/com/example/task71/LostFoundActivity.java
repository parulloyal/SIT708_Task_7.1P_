package com.example.task71;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.task71.databinding.ActivityLostFoundBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LostFoundActivity extends AppCompatActivity {
    private ActivityLostFoundBinding binding;
    private List<LostFoundData> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLostFoundBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        itemList = new ArrayList<>();
        binding.rLost.setChecked(true);

        binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = findViewById(checkedId);
                if (checkedRadioButton.getId() == R.id.r_lost) {
                } else if (checkedRadioButton.getId() == R.id.r_found) {
                }
            }
        });
        binding.tvSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateFields()) {
                    saveData();
                }
            }
        });
    }

    private boolean validateFields() {
        if (binding.radioGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(binding.etName.getText().toString().trim())) {
            binding.warningName.setVisibility(View.VISIBLE);
            return false;
        }else {
            binding.warningName.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etPhone.getText().toString().trim())) {
            binding.warningPhone.setVisibility(View.VISIBLE);
            return false;
        }
        else {
            binding.warningPhone.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etDescription.getText().toString().trim())) {
            binding.warningDescription.setVisibility(View.VISIBLE);
            return false;
        }else {
            binding.warningDescription.setVisibility(View.GONE);
        }

        String date = binding.etDate.getText().toString().trim();
        if (TextUtils.isEmpty(date)) {
            binding.warningDate.setVisibility(View.VISIBLE);
            return false;
        } else {
            if (!isValidDateFormat(date)) {
                binding.warningDate.setVisibility(View.GONE);
                Toast.makeText(this, "Invalid date format (yyyy/mm/dd)", Toast.LENGTH_SHORT).show();
                return false;
            }
            binding.warningDate.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etLocation.getText().toString().trim())) {
            binding.warningLocation.setVisibility(View.VISIBLE);
            return false;
        }else {
            binding.warningLocation.setVisibility(View.GONE);
        }
        return true;
    }
    private void saveData() {
        int radioButtonId = binding.radioGroup.getCheckedRadioButtonId();
        if (radioButtonId == -1) {
            Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton radioButton = findViewById(radioButtonId);
        String type = radioButton.getText().toString();

        String name = binding.etName.getText().toString().trim();
        String phone = binding.etPhone.getText().toString().trim();
        String description = binding.etDescription.getText().toString().trim();
        String date = binding.etDate.getText().toString().trim();
        String location = binding.etLocation.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(description)
                || TextUtils.isEmpty(date) || TextUtils.isEmpty(location)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("itemList", "");
        Gson gson = new Gson();
        Type typeToken = new TypeToken<List<LostFoundData>>() {}.getType();
        List<LostFoundData> itemList;
        if (!json.isEmpty()) {
            itemList = gson.fromJson(json, typeToken);
        } else {
            itemList = new ArrayList<>();
        }

        LostFoundData item = new LostFoundData();
        item.setType(type);
        item.setName(name);
        item.setPhone(phone);
        item.setDescription(description);
        item.setDate(date);
        item.setLocation(location);

        itemList.add(item);
        String updatedJson = gson.toJson(itemList);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("itemList", updatedJson);
        editor.apply();
        Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show();
        finish();
    }
    private boolean isValidDateFormat(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
        sdf.setLenient(false); // Ensure strict date parsing
        try {
            Date date = sdf.parse(dateStr);
            // Date parsing succeeded, so the format is valid
            return true;
        } catch (ParseException e) {
            // Date parsing failed, indicating an invalid format
            return false;
        }
}}