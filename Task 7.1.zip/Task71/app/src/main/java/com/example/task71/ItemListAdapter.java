package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.task71.databinding.ItemListBinding;

import java.io.Serializable;
import java.util.List;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ViewHolder> {
    private List<LostFoundData> itemList;
    private Context context;

    public ItemListAdapter(Context context, List<LostFoundData> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemListBinding binding = ItemListBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LostFoundData item = itemList.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemListBinding binding;

        public ViewHolder(@NonNull ItemListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        LostFoundData clickedItem = itemList.get(position);
                        Intent intent = new Intent(context, ItemDetailsActivity.class);
                        intent.putExtra("itemList", (Serializable) itemList);
                        intent.putExtra("position", position);
                        context.startActivity(intent);
                    }
                }
            });
        }

        public void bind(LostFoundData item) {
            if (item.getName() != null) {
                binding.tvType.setText(item.getType());
                binding.tvName.setText(item.getName());
            } else {
                binding.tvName.setText("Unknown Name");
            }
        }
    }
}
